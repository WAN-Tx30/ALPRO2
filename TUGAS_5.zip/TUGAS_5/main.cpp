#include <iostream>

using namespace std;

// PARAMETER FORMAL
int isKelipatan3(int x) {
    return x % 3 == 0 ? 1 : 0;
}

int main() {
    //1.Sebuah fungsi untuk menentukan bil termasuk genap atau ganjil.
    int number;
    cout << "maukkan nilai: ";
    cin >> number;

    if (number % 2 == 0) {
        cout << "Bilangan Genap" << endl;
    } else {
        cout << "Bilangan Ganjil" << endl;
    }

    //2.Sebuah fungsi untuk menentukan bil termasuk kelipatan 3 atau tidak.
    if (isKelipatan3(number)) {
        cout << "Bilangan Kelipatan 3" << endl;
    } else {
        cout << "Bilangan Bukan Kelipatan 3" << endl;
    }

    return 0;
}
