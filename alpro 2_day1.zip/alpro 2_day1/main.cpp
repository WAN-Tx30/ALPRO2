#include <iostream>

using namespace std;
string nama,nim;
int umur;
int b = 0;

int main()
{
    cout << "Nama  =";
    cin >>nama;
    cout << "Umur  =";
    cin >>umur;


    for (int i = 0; i < umur; i++) {
        cout << umur<<endl;
    }

    do {
        cout <<b<<nama<<endl;
      b++;
    }
    while (b <= umur);
    return 0;
}


